# CVita — The Living Career Story Platform

> Your Career Story. Your Knowledge. Your Income.

## What's inside

CVita is a full-stack career platform with 7 pages:

| Page | Description |
|------|-------------|
| 🏠 Landing | Conversion-focused homepage with email capture & social proof |
| 💰 Pricing | Plans for professionals ($0–$99) and recruiters ($99–$899) |
| 👤 Dashboard | CV editor (10 sections), inline AI optimization, earnings panel |
| 🛒 Market | Public knowledge marketplace — buy courses, templates, ebooks |
| 💼 Jobs | Hashtag-matched job board with one-click apply |
| 🔍 Recruiter | Hashtag-powered candidate search with contact unlock paywall |
| 🤖 AI Agents | 6 autonomous AI agents with credit system |

---

## 🚀 Deploy to Vercel (Recommended — Free, 2 minutes)

### Option A: Deploy via Vercel CLI

```bash
# 1. Install dependencies
npm install

# 2. Install Vercel CLI
npm install -g vercel

# 3. Deploy (follow prompts)
vercel

# Your site will be live at: https://cvita.vercel.app (or your custom domain)
```

### Option B: Deploy via Vercel Dashboard (No CLI needed)

1. Go to **[github.com](https://github.com)** → Create a new repository named `cvita`
2. Upload all these files to the repository
3. Go to **[vercel.com](https://vercel.com)** → Sign up free
4. Click **"Add New Project"** → Import your GitHub repo
5. Vercel auto-detects Vite — just click **"Deploy"**
6. ✅ Live in ~60 seconds at `https://cvita-xxx.vercel.app`

---

## 🌐 Deploy to Netlify (Also Free)

```bash
# 1. Install dependencies
npm install

# 2. Build the project
npm run build

# 3. Go to netlify.com → "Add new site" → "Deploy manually"
# 4. Drag & drop the /dist folder
# ✅ Live instantly
```

---

## 💻 Run locally

```bash
npm install
npm run dev
# Opens at http://localhost:5173
```

---

## 🔗 Connect your own domain

After deploying to Vercel or Netlify:
1. Go to your project settings → Domains
2. Add `cvita.io` (or your domain)
3. Point your DNS to the provided nameservers
4. Free SSL certificate is added automatically

---

## 🤖 Connect real Claude AI (for AI Agents)

To make the AI Agents call real Claude API:

1. Get an API key from [console.anthropic.com](https://console.anthropic.com)
2. Create a `.env` file:
```
VITE_ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxx
```
3. In `src/App.jsx`, find the `Agents` component and replace the mock `setTimeout` with a real API call

> ⚠️ For production, always call the Anthropic API from a backend (Next.js API route, Edge Function, etc.) — never expose your API key in client-side code.

---

## 📁 Project structure

```
cvita/
├── index.html          # App entry point
├── vite.config.js      # Vite config
├── vercel.json         # Vercel SPA routing
├── netlify.toml        # Netlify build config
├── package.json        # Dependencies
└── src/
    ├── main.jsx        # React root
    ├── index.css       # Global styles & animations
    └── App.jsx         # Full CVita application (all 7 pages)
```

---

## 💡 Next steps to monetize

1. **Stripe** — Add Stripe Checkout for Pro/Creator subscriptions and knowledge sales
2. **Supabase** — Add a database for real user profiles and knowledge items  
3. **Anthropic API** — Wire up real Claude for AI agents
4. **Custom domain** — Register `cvita.io` or `cvita.app`
5. **Email** — Add Resend or Postmark for welcome emails and payout notifications

---

Built with React + Vite · Powered by Claude AI
