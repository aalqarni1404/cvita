import { useState } from "react";

const T = {
  bg:"#f5f7fc", surface:"#fff", panel:"#f0f2f8", border:"#e2e6f0",
  text:"#0d1117", mid:"#445069", mute:"#8694b0",
  dark:"#0a0f1e", blue:"#2563eb", blueBg:"#eff6ff", blueBrd:"#bfdbfe",
  gold:"#d97706", goldBg:"#fffbeb", goldBrd:"#fcd34d",
  green:"#059669", greenBg:"#ecfdf5", greenBrd:"#6ee7b7",
  purple:"#7c3aed", purpleBg:"#f5f3ff", purpleBrd:"#ddd6fe",
  red:"#dc2626", redBg:"#fef2f2", redBrd:"#fecaca",
  teal:"#0891b2", orange:"#ea580c",
};

const Btn = ({ children, v="primary", onClick, disabled, size="md", style={} }) => {
  const p = size==="sm"?"6px 13px":size==="lg"?"14px 32px":"9px 20px";
  const fs = size==="sm"?"10px":size==="lg"?"14px":"12px";
  const vs = {
    primary:{ background:`linear-gradient(135deg,${T.blue},#3b82f6)`, color:"#fff", border:"none" },
    ghost:  { background:"transparent", color:T.mid, border:`1px solid ${T.border}` },
  };
  const s = vs[v]||vs.primary;
  return <button onClick={onClick} disabled={disabled} style={{...s,padding:p,fontFamily:"monospace",fontSize:fs,fontWeight:"bold",cursor:disabled?"not-allowed":"pointer",borderRadius:"7px",opacity:disabled?0.5:1,transition:"all 0.15s",...style}}>{children}</button>;
};

const Badge = ({label,color,bg}) => (
  <span style={{display:"inline-flex",alignItems:"center",gap:"3px",fontFamily:"monospace",fontSize:"10px",fontWeight:"700",color,background:bg,border:`1px solid ${color}33`,padding:"2px 8px",borderRadius:"20px",whiteSpace:"nowrap"}}>{label}</span>
);

const Card = ({children,style={}}) => (
  <div style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:"12px",padding:"16px",boxShadow:"0 1px 4px rgba(0,0,0,0.05)",...style}}>{children}</div>
);

function uid(){ return Math.random().toString(36).slice(2,8); }

const PLANS = [
  { id:"free", name:"Free", price:0, color:T.mute, tag:"", cta:"Start Free" },
  { id:"pro", name:"Pro", price:15, color:T.blue, tag:"MOST POPULAR", cta:"Start Pro — $15/mo" },
  { id:"creator", name:"Creator", price:29, color:T.gold, tag:"BEST EARNINGS", cta:"Start Creator — $29/mo" },
  { id:"ent", name:"Enterprise", price:99, color:T.purple, tag:"FOR TEAMS", cta:"Contact Sales" },
];

const MARKET_ITEMS = [
  { id:uid(), title:"UX Research Methods Masterclass", price:49, desc:"6-week deep dive into research methods." },
  { id:uid(), title:"Product Strategy for SaaS Leaders", price:79, desc:"Framework for roadmaps aligned with business goals." },
  { id:uid(), title:"Full-Stack API Architecture Workshop", price:59, desc:"Scalable REST & GraphQL APIs." },
];

const JOBS = [
  { id:uid(), co:"Stripe", role:"Senior Product Designer", loc:"SF / Remote", type:"Full-time", salary:"$140k–$180k" },
  { id:uid(), co:"Vercel", role:"UX Designer — Design Systems", loc:"Remote", type:"Full-time", salary:"$110k–$140k" },
  { id:uid(), co:"Linear", role:"Product Manager", loc:"Remote", type:"Full-time", salary:"$130k–$165k" },
];

function Landing({ goto }) {
  const [email, setEmail] = useState("");
  const [joined, setJoined] = useState(false);
  return (
    <div style={{background:T.dark,color:"#e2e8f0",fontFamily:"Georgia,serif",minHeight:"100vh"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Space+Grotesk:wght@400;500;700&display=swap');*{box-sizing:border-box;margin:0;padding:0;}`}</style>
      <div style={{padding:"72px 24px 52px",maxWidth:"860px",margin:"0 auto",textAlign:"center"}}>
        <h1 style={{fontFamily:"Playfair Display,serif",fontSize:"clamp(36px,6.5vw,66px)",fontWeight:"900",lineHeight:"1.08",marginBottom:"20px"}}>
          <span style={{background:"linear-gradient(135deg,#e2e8f0 40%,#60a5fa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Your Career Story.</span><br/>
          <span style={{background:"linear-gradient(135deg,#60a5fa,#a78bfa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Your Knowledge.</span><br/>
          <span style={{background:"linear-gradient(135deg,#a78bfa,#f59e0b)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Your Income.</span>
        </h1>
        <p style={{fontFamily:"Space Grotesk",fontSize:"17px",color:"#94a3b8",lineHeight:"1.7",maxWidth:"560px",margin:"0 auto 32px"}}>
          Turn your CV into a revenue engine — sell knowledge, get discovered by recruiters, and let AI agents optimize everything.
        </p>
        {!joined ? (
          <div style={{display:"flex",gap:"8px",justifyContent:"center",flexWrap:"wrap"}}>
            <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="your@email.com" style={{width:"270px",background:"#0f1628",border:"1px solid #2d4060",color:"#e2e8f0",fontFamily:"Space Grotesk",fontSize:"14px",padding:"13px 16px",outline:"none",borderRadius:"8px"}} />
            <button onClick={()=>{if(email)setJoined(true);}} style={{background:`linear-gradient(135deg,${T.blue},#3b82f6)`,color:"#fff",border:"none",padding:"13px 26px",fontFamily:"monospace",fontSize:"13px",fontWeight:"bold",cursor:"pointer",borderRadius:"8px"}}>GET STARTED FREE →</button>
          </div>
        ) : (
          <div style={{display:"inline-flex",alignItems:"center",gap:"9px",background:T.greenBg,border:`1px solid ${T.greenBrd}`,borderRadius:"10px",padding:"12px 20px"}}>
            <span>🎉</span><span style={{fontFamily:"Space Grotesk",fontSize:"14px",color:T.green,fontWeight:"600"}}>You're on the list!</span>
          </div>
        )}
        <div style={{display:"flex",gap:"11px",justifyContent:"center",flexWrap:"wrap",marginTop:"28px"}}>
          <button onClick={()=>goto("dashboard")} style={{background:`linear-gradient(135deg,${T.blue},#3b82f6)`,color:"#fff",border:"none",padding:"13px 28px",fontFamily:"monospace",fontSize:"13px",fontWeight:"bold",cursor:"pointer",borderRadius:"8px"}}>Open Dashboard</button>
          <button onClick={()=>goto("market")} style={{background:"transparent",border:"1px solid #2d4060",color:"#94a3b8",padding:"13px 20px",fontFamily:"monospace",fontSize:"13px",cursor:"pointer",borderRadius:"8px"}}>Browse Marketplace</button>
        </div>
      </div>
    </div>
  );
}

function Pricing() {
  return <div style={{background:T.bg,minHeight:"100vh",padding:"38px 24px",fontFamily:"Georgia,serif"}}>
    <div style={{maxWidth:"1040px",margin:"0 auto"}}>
      <div style={{textAlign:"center",marginBottom:"32px"}}>
        <div style={{fontFamily:"monospace",fontSize:"10px",color:T.mute,letterSpacing:"2px",marginBottom:"12px"}}>PRICING</div>
        <div style={{fontFamily:"Playfair Display,serif",fontSize:"28px",fontWeight:"900",color:T.text}}>Pay when CVita makes you money</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(225px,1fr))",gap:"13px"}}>
        {PLANS.map(plan=><div key={plan.id} style={{background:T.surface,border:`2px solid ${plan.color===T.mute?T.border:plan.color}`,borderRadius:"14px",overflow:"hidden"}}>
          {plan.tag&&<div style={{background:plan.color,padding:"5px",textAlign:"center",fontFamily:"monospace",fontSize:"9px",fontWeight:"bold",color:"#fff"}}>{plan.tag}</div>}
          <div style={{padding:"20px"}}>
            <div style={{fontFamily:"monospace",fontSize:"13px",fontWeight:"bold",color:plan.color,marginBottom:"7px"}}>{plan.name}</div>
            <div style={{display:"flex",alignItems:"baseline",gap:"4px",marginBottom:"14px"}}>
              <span style={{fontFamily:"Playfair Display,serif",fontSize:"32px",fontWeight:"900",color:T.text}}>${plan.price}</span>
              <span style={{fontFamily:"monospace",fontSize:"11px",color:T.mute}}>/month</span>
            </div>
            <button style={{width:"100%",padding:"10px",fontFamily:"monospace",fontSize:"11px",fontWeight:"bold",cursor:"pointer",borderRadius:"7px",border:"none",background:plan.color===T.mute?T.panel:`linear-gradient(135deg,${plan.color},${plan.color}bb)`,color:"#fff"}}>{plan.cta}</button>
          </div>
        </div>)}
      </div>
    </div>
  </div>;
}

function Dashboard({ goto }) {
  return <div style={{background:T.bg,minHeight:"100vh",fontFamily:"Georgia,serif"}}>
    <div style={{background:T.surface,borderBottom:`1px solid ${T.border}`,padding:"0 16px",height:"48px",display:"flex",alignItems:"center",gap:"10px"}}>
      <span style={{fontFamily:"Playfair Display,serif",fontSize:"14px",fontWeight:"900",color:T.text}}>Alex Morgan</span>
      <span style={{fontFamily:"monospace",fontSize:"10px",color:T.mute}}>Senior Product Designer</span>
      <div style={{marginLeft:"auto",display:"flex",gap:"6px",alignItems:"center"}}>
        <Badge label="PRO" color={T.blue} bg={T.blueBg}/>
        <Btn v="ghost" size="sm" onClick={()=>goto("market")}>My Shop</Btn>
        <Btn v="ghost" size="sm" onClick={()=>goto("jobs")}>Jobs</Btn>
      </div>
    </div>
    <div style={{padding:"24px",maxWidth:"960px",margin:"0 auto"}}>
      <Card>
        <div style={{fontFamily:"Playfair Display,serif",fontSize:"18px",fontWeight:"700",marginBottom:"8px"}}>Dashboard</div>
        <div style={{fontFamily:"Space Grotesk",fontSize:"14px",color:T.mid}}>This is the deployable frontend version of the CVita prototype.</div>
      </Card>
    </div>
  </div>;
}

function Market() {
  const [cart, setCart] = useState([]);
  const total = cart.reduce((s,id)=>s+(MARKET_ITEMS.find(i=>i.id===id)?.price||0),0);
  return <div style={{background:T.bg,minHeight:"100vh",fontFamily:"Georgia,serif"}}>
    <div style={{background:`linear-gradient(135deg,${T.dark},#1e2d45)`,padding:"32px 24px",textAlign:"center",color:"#e2e8f0"}}>
      <div style={{fontFamily:"monospace",fontSize:"10px",color:"#334155",letterSpacing:"2px",marginBottom:"7px"}}>KNOWLEDGE MARKETPLACE</div>
      <div style={{fontFamily:"Playfair Display,serif",fontSize:"24px",fontWeight:"900"}}>Learn from world-class professionals</div>
    </div>
    <div style={{maxWidth:"1040px",margin:"0 auto",padding:"20px 22px"}}>
      {cart.length>0&&<div style={{background:`linear-gradient(135deg,${T.purple},#6d28d9)`,borderRadius:"10px",padding:"11px 14px",marginBottom:"13px",display:"flex",alignItems:"center",gap:"12px"}}><span style={{fontFamily:"monospace",fontSize:"12px",color:"#fff",fontWeight:"bold"}}>Cart total: ${total}</span></div>}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:"13px"}}>
        {MARKET_ITEMS.map(item=><div key={item.id} style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:"13px",overflow:"hidden"}}>
          <div style={{padding:"14px"}}>
            <div style={{fontFamily:"Playfair Display,serif",fontSize:"14px",fontWeight:"700",color:T.text,marginBottom:"5px"}}>{item.title}</div>
            <div style={{fontFamily:"Space Grotesk",fontSize:"12px",color:T.mid,marginBottom:"8px"}}>{item.desc}</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{fontFamily:"monospace",fontSize:"20px",fontWeight:"bold",color:T.text}}>${item.price}</div>
              <Btn size="sm" onClick={()=>setCart(c=>[...c,item.id])}>Add to cart</Btn>
            </div>
          </div>
        </div>)}
      </div>
    </div>
  </div>;
}

function Jobs() {
  return <div style={{background:T.bg,minHeight:"100vh",fontFamily:"Georgia,serif"}}>
    <div style={{background:`linear-gradient(135deg,${T.dark},#1a2640)`,padding:"30px 24px",color:"#e2e8f0"}}>
      <div style={{maxWidth:"940px",margin:"0 auto"}}>
        <div style={{fontFamily:"monospace",fontSize:"10px",color:"#334155",letterSpacing:"2px",marginBottom:"7px"}}>JOB BOARD</div>
        <div style={{fontFamily:"Playfair Display,serif",fontSize:"22px",fontWeight:"900"}}>Jobs matched to your hashtags</div>
      </div>
    </div>
    <div style={{maxWidth:"940px",margin:"0 auto",padding:"20px 22px",display:"flex",flexDirection:"column",gap:"10px"}}>
      {JOBS.map(job=><div key={job.id} style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:"12px",padding:"15px"}}>
        <div style={{fontFamily:"Playfair Display,serif",fontSize:"15px",fontWeight:"700",color:T.text}}>{job.role}</div>
        <div style={{fontFamily:"monospace",fontSize:"11px",color:T.mid,marginBottom:"6px"}}>{job.co} · {job.loc} · {job.type}</div>
        <div style={{fontFamily:"monospace",fontSize:"12px",color:T.green,fontWeight:"bold"}}>{job.salary}</div>
      </div>)}
    </div>
  </div>;
}

export default function App() {
  const [page, setPage] = useState("landing");
  const NAV = [
    {id:"landing", label:"Home"},
    {id:"dashboard", label:"Dashboard"},
    {id:"market", label:"Marketplace"},
    {id:"jobs", label:"Jobs"},
    {id:"pricing", label:"Pricing"},
  ];
  return (
    <div>
      <style>{`*{box-sizing:border-box;} body{margin:0}`}</style>
      <div style={{position:"sticky",top:0,zIndex:200,background:"rgba(10,15,30,0.97)",borderBottom:"1px solid #1c2d45",display:"flex",alignItems:"center",gap:"3px",padding:"0 12px",height:"52px",overflowX:"auto"}}>
        <div style={{display:"flex",alignItems:"center",gap:"6px",marginRight:"8px",cursor:"pointer",flexShrink:0}} onClick={()=>setPage("landing")}>
          <div style={{width:"20px",height:"20px",background:`linear-gradient(135deg,#2563eb,#60a5fa)`,clipPath:"polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%)"`}}/>
          <span style={{fontFamily:"Playfair Display,serif",fontSize:"15px",fontWeight:"900",color:"#e2e8f0",whiteSpace:"nowrap"}}>CV<span style={{color:"#60a5fa"}}>ita</span></span>
        </div>
        {NAV.map(n=><button key={n.id} onClick={()=>setPage(n.id)} style={{background:page===n.id?"#1d3a6e":"transparent",border:`1px solid ${page===n.id?"#2563eb55":"transparent"}`,color:page===n.id?"#60a5fa":"#5a7090",padding:"5px 11px",fontFamily:"monospace",fontSize:"11px",cursor:"pointer",borderRadius:"6px",whiteSpace:"nowrap",flexShrink:0}}>{n.label}</button>)}
      </div>
      {page==="landing" && <Landing goto={setPage} />}
      {page==="dashboard" && <Dashboard goto={setPage} />}
      {page==="market" && <Market />}
      {page==="jobs" && <Jobs />}
      {page==="pricing" && <Pricing />}
    </div>
  );
}
