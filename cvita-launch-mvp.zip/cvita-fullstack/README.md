# CVita MVP Launch Starter

This codebase is no longer just a UI mock. It now behaves like a launch-oriented MVP for a career platform and knowledge marketplace.

## What is included now

- cookie auth with signup, login, logout, and current-user endpoint
- protected dashboard, seller studio, recruiter area, billing routes, and AI routes
- editable professional profile persisted to the database
- public profile pages at `/u/[slug]`
- marketplace browsing plus seller product publishing/editing
- persistent cart and order creation route
- job list plus authenticated apply/save actions
- recruiter candidate unlock flow with credit deduction
- AI run endpoint with credit deduction and saved run rows
- Stripe subscription checkout and billing portal wiring
- legal/support pages: privacy, terms, contact
- sitemap and robots metadata routes
- launch checklist page for business readiness

## Run locally

```bash
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev
```

## Demo accounts

Password for all: `password123`

- alex@cvita.dev
- james@cvita.dev
- priya@cvita.dev
- omar@cvita.dev
- recruiter@cvita.dev

## Important product routes

- `/` home with auth panel
- `/dashboard` profile editor
- `/seller` seller studio
- `/u/alex-morgan` public profile example
- `/market`
- `/jobs`
- `/recruiter`
- `/agents`
- `/pricing`
- `/privacy`
- `/terms`
- `/contact`
- `/launch`

## API routes

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/profile/me`
- `PATCH /api/profile/me`
- `GET|POST|PATCH /api/seller/products`
- `GET /api/market/items`
- `GET|POST|DELETE /api/market/cart`
- `POST /api/market/checkout`
- `GET /api/jobs`
- `POST /api/jobs/:id/apply`
- `POST|DELETE /api/jobs/:id/save`
- `GET /api/recruiter/candidates`
- `POST /api/recruiter/candidates/:id/unlock`
- `POST /api/ai/run`
- `POST /api/billing/checkout`
- `POST /api/billing/portal`
- `POST /api/stripe/webhook`

## Before going live

1. Configure production database and run `prisma migrate deploy`
2. Replace placeholder support/sales emails
3. Configure live Stripe keys, prices, and webhooks
4. Remove demo seed users from production
5. Add file upload storage and thumbnails for products
6. Add email verification, password reset, and transactional emails
7. Add monitoring, logging, rate limits, backups, and error tracking
8. Write real refund and moderation policies

## Blunt truth

This is now strong MVP code, not finished production SaaS.

You still need:
- real deployment and build verification
- stronger production auth hardening beyond starter cookie sessions
- email flows
- storage
- automated tests
- admin moderation and support tooling
- tax/compliance review for your jurisdiction
