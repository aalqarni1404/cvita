import { NextRequest, NextResponse } from "next/server";

const protectedPrefixes = ["/dashboard", "/seller", "/agents", "/recruiter", "/api/market/cart", "/api/market/checkout", "/api/profile", "/api/ai/run", "/api/billing", "/api/seller"];

export function middleware(request: NextRequest) {
  const { pathname, search } = request.nextUrl;
  const session = request.cookies.get("cvita_session")?.value;
  const isProtected = protectedPrefixes.some((prefix) => pathname === prefix || pathname.startsWith(prefix + "/"));
  if (!isProtected) return NextResponse.next();
  if (session) return NextResponse.next();

  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const url = request.nextUrl.clone();
  url.pathname = "/";
  url.searchParams.set("next", pathname + search);
  url.searchParams.set("auth", "required");
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ["/dashboard/:path*", "/seller/:path*", "/agents/:path*", "/recruiter/:path*", "/api/market/:path*", "/api/profile/:path*", "/api/ai/:path*", "/api/billing/:path*", "/api/seller/:path*"]
};
