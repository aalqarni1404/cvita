import { BillingInterval, Plan, PrismaClient, ProductType, UserRole } from "@prisma/client";
import bcrypt from "bcryptjs";
import { APP_PLANS } from "../lib/plans";

const prisma = new PrismaClient();

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

async function createProfessional(email:string, fullName:string, plan:Plan, aiCredits:number, profile:any){
  const hash=await bcrypt.hash("password123",10);
  return prisma.user.create({ data:{ email, passwordHash:hash, fullName, role:UserRole.PROFESSIONAL, plan, aiCredits, profile:{ create: { slug: slugify(fullName), ...profile } } } });
}

async function main(){
  await prisma.session.deleteMany();
  await prisma.application.deleteMany();
  await prisma.savedJob.deleteMany();
  await prisma.cartItem.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.productTag.deleteMany();
  await prisma.product.deleteMany();
  await prisma.jobTag.deleteMany();
  await prisma.job.deleteMany();
  await prisma.hashtag.deleteMany();
  await prisma.experience.deleteMany();
  await prisma.patent.deleteMany();
  await prisma.venture.deleteMany();
  await prisma.profile.deleteMany();
  await prisma.candidateUnlock.deleteMany();
  await prisma.aiAgentRun.deleteMany();
  await prisma.subscription.deleteMany();
  await prisma.subscriptionPlan.deleteMany();
  await prisma.user.deleteMany();

  for (const [code, plan] of Object.entries(APP_PLANS)) {
    await prisma.subscriptionPlan.create({
      data: {
        code: code as Plan,
        name: plan.name,
        description: plan.description,
        priceMonthlyCents: plan.monthly,
        priceYearlyCents: plan.yearly,
        aiCredits: plan.aiCredits,
        recruiterCredits: plan.recruiterCredits,
        stripePriceMonthly: process.env[`STRIPE_PRICE_${code}_MONTHLY`] || null,
        stripePriceYearly: process.env[`STRIPE_PRICE_${code}_YEARLY`] || null
      }
    });
  }

  const alex=await createProfessional("alex@cvita.dev","Alex Morgan",Plan.PRO,5,{ title:"Senior Product Designer", location:"San Francisco", status:"🟢 Open to Work", summary:"Systems-minded product designer building scalable design platforms.", careerScore:82, experiences:{ create:[{ title:"Senior Product Designer", organization:"Figma Inc.", period:"Mar 2022–Present", bullets:["Led redesign of component library, reducing design debt by 40%","Collaborated with 12 PMs to ship 3 major product features","Mentored 4 junior designers across EMEA"]}]}, hashtags:{ create:["ProductDesign","UXDesign","OpenToWork","DesignSystems","Figma","RemoteWork","AI"].map(label=>({ label })) }, patents:{ create:[{ title:"Adaptive UI Component Layout System", number:"US11,234,567", status:"Granted" }] }, ventures:{ create:[{ name:"DesignOS Studio", role:"Founder & CEO", stage:"Profitable", revenue:"$420k ARR", teamSize:8 }] } });
  const james = await createProfessional("james@cvita.dev","James Okafor",Plan.FREE,3,{ title:"Full Stack Engineer", location:"Remote", status:"🟢 Open to Work", summary:"Backend-focused engineer shipping Node, React, and cloud systems.", careerScore:91, experiences:{ create:[{ title:"Senior Full Stack Engineer", organization:"DevFlow", period:"2021–Present", bullets:["Built internal platform APIs used by 40+ engineers","Reduced API latency by 35% with caching and query tuning"]}]}, hashtags:{ create:["FullStack","React","Python","Backend","OpenToWork","RemoteWork","DevOps"].map(label=>({ label })) } });
  const priya = await createProfessional("priya@cvita.dev","Priya Nair",Plan.CREATOR,8,{ title:"Product Manager", location:"London", status:"🔵 Networking", summary:"B2B SaaS product manager focused on growth, monetization, and roadmap execution.", careerScore:75, experiences:{ create:[{ title:"Senior Product Manager", organization:"ScaleLoop", period:"2022–Present", bullets:["Owned product roadmap across acquisition and billing","Shipped onboarding improvements that lifted activation by 22%"]}]}, hashtags:{ create:["ProductManager","Agile","SaaS","B2B","Networking","FinTech"].map(label=>({ label })) } });
  await createProfessional("omar@cvita.dev","Omar Al-Rashid",Plan.PRO,6,{ title:"Data Scientist", location:"Dubai", status:"🟢 Open to Work", summary:"Applied ML and analytics practitioner focused on fintech use cases.", careerScore:88, experiences:{ create:[{ title:"Data Scientist", organization:"FinML", period:"2023–Present", bullets:["Built fraud models that reduced false positives by 19%","Operationalized scoring workflows in Python and SQL"]}]}, hashtags:{ create:["DataScience","AI","Python","OpenToWork","FinTech","MachineLearning"].map(label=>({ label })) } });

  const recruiterHash = await bcrypt.hash("password123",10);
  const recruiter = await prisma.user.create({ data:{ email:"recruiter@cvita.dev", passwordHash:recruiterHash, fullName:"Riley Recruiter", role:UserRole.RECRUITER, plan:Plan.ENTERPRISE, aiCredits:50, recruiterCredits:3 } });
  const enterprisePlan = await prisma.subscriptionPlan.findUniqueOrThrow({ where: { code: Plan.ENTERPRISE } });
  await prisma.subscription.create({ data: { userId: recruiter.id, subscriptionPlanId: enterprisePlan.id, interval: BillingInterval.MONTH, status: "active" } });

  for (const product of [
    { creatorId: alex.id, title:"UX Research Methods Masterclass", description:"6-week deep dive into qualitative and quantitative research methods with templates and certificate-ready coursework.", type:ProductType.COURSE, priceCents:4900, rating:4.9, reviews:187, students:1240, tags:["UXResearch","Design"] },
    { creatorId: alex.id, title:"Design Systems Slide Deck Template", description:"80-slide template for product teams with component variants and tokens ready for workshops and exec reviews.", type:ProductType.TEMPLATE, priceCents:1900, rating:4.7, reviews:312, students:2100, tags:["Figma","DesignSystems"] },
    { creatorId: james.id, title:"Full-Stack API Architecture Workshop", description:"Scalable REST and GraphQL APIs: auth, caching, deployment, observability, and production hardening.", type:ProductType.WORKSHOP, priceCents:5900, rating:4.8, reviews:76, students:430, tags:["Backend","NodeJS"] },
    { creatorId: priya.id, title:"Product Strategy for SaaS Leaders", description:"Monetization, roadmap, and stakeholder planning frameworks for B2B SaaS teams going from seed to scale-up.", type:ProductType.COURSE, priceCents:7900, rating:4.8, reviews:134, students:890, tags:["ProductStrategy","SaaS"] }
  ]) {
    await prisma.product.create({ data:{ creatorId:product.creatorId, title:product.title, description:product.description, type:product.type, priceCents:product.priceCents, rating:product.rating, reviews:product.reviews, students:product.students, tags:{ create:product.tags.map(label=>({ label })) } } });
  }

  for (const job of [{ company:"Stripe", logo:"💳", title:"Senior Product Designer", location:"SF / Remote", jobType:"Full-time", salary:"$140k–$180k", posted:"2d", applicants:47, matchScore:94, urgent:true, tags:["ProductDesign","Figma","DesignSystems","FinTech"] },{ company:"Notion", logo:"📝", title:"Head of Design", location:"Remote", jobType:"Full-time", salary:"$160k–$210k", posted:"1d", applicants:89, matchScore:88, urgent:false, tags:["ProductDesign","Leadership","DesignSystems"] },{ company:"Luma AI", logo:"🔮", title:"AI Product Designer", location:"SF / Hybrid", jobType:"Hybrid", salary:"$150k–$195k", posted:"1d", applicants:33, matchScore:89, urgent:true, tags:["ProductDesign","AI","MachineLearning"] },{ company:"Vercel", logo:"▲", title:"Full Stack Engineer", location:"Remote", jobType:"Full-time", salary:"$130k–$170k", posted:"3d", applicants:61, matchScore:92, urgent:false, tags:["React","Backend","FullStack"] }]) {
    await prisma.job.create({ data:{ company:job.company, logo:job.logo, title:job.title, location:job.location, jobType:job.jobType, salary:job.salary, posted:job.posted, applicants:job.applicants, matchScore:job.matchScore, urgent:job.urgent, tags:{ create:job.tags.map(label=>({ label })) } } });
  }
}

main().then(async()=>{await prisma.$disconnect();}).catch(async(e)=>{console.error(e); await prisma.$disconnect(); process.exit(1);});
