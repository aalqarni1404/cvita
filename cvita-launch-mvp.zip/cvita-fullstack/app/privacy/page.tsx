import { Card, SectionLabel } from "@/components/ui";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return <main style={{ maxWidth: 900, margin: "0 auto", padding: "28px 20px 64px" }}><Card><SectionLabel>LEGAL</SectionLabel><h1 style={{ marginTop: 0, fontSize: 34 }}>Privacy Policy</h1><div style={{ color: "#445069", lineHeight: 1.8, fontSize: 15 }}>We collect account, billing, and activity data only to run the product, process payments, fight abuse, and improve matching, marketplace, and recruiting features. We do not sell user data. Recruiter unlocks, purchases, and account actions are logged for fraud prevention and support. You can request export or deletion of your account data by contacting support. Replace this starter text with counsel-reviewed language before launch.</div></Card></main>;
}
