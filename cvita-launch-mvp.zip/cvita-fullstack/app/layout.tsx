import type { Metadata } from "next";
import { ReactNode } from "react";
import { Nav } from "@/components/Nav";

const baseUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(baseUrl),
  title: { default: "CVita", template: "%s · CVita" },
  description: "Career profiles, recruiter discovery, AI career tools, and a knowledge marketplace in one app.",
  keywords: ["career platform", "knowledge marketplace", "recruiter search", "AI career tools", "portfolio"],
  openGraph: {
    title: "CVita",
    description: "Career profiles, recruiter discovery, AI career tools, and a knowledge marketplace in one app.",
    url: baseUrl,
    siteName: "CVita",
    type: "website"
  },
  twitter: {
    card: "summary_large_image",
    title: "CVita",
    description: "Career profiles, recruiter discovery, AI career tools, and a knowledge marketplace in one app."
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, background: "#f5f7fc", color: "#0d1117", fontFamily: "Georgia, serif" }}>
        <Nav />
        {children}
      </body>
    </html>
  );
}
