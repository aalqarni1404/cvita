import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Card, SectionLabel } from "@/components/ui";
import { T } from "@/components/theme";
import { DashboardClient } from "@/components/client/DashboardClient";

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <main style={{ maxWidth: 900, margin: "0 auto", padding: 24 }}>
        <Card>
          <SectionLabel>DASHBOARD</SectionLabel>
          <h1 style={{ marginTop: 0 }}>Sign in first</h1>
          <p style={{ color: T.mid }}>Dashboard editing is tied to the authenticated user now.</p>
          <Link href="/" style={{ color: T.blue, fontFamily: "monospace" }}>Go to home and sign in</Link>
        </Card>
      </main>
    );
  }

  const profile = await prisma.profile.findUnique({
    where: { userId: user.id },
    include: {
      user: true,
      experiences: true,
      hashtags: true,
      patents: true,
      ventures: true
    }
  });

  if (!profile) {
    return <main style={{ padding: 24 }}>No profile found for this user.</main>;
  }

  return <DashboardClient initialProfile={JSON.parse(JSON.stringify(profile))} />;
}
