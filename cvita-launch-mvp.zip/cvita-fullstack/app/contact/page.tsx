import { Card, SectionLabel } from "@/components/ui";

export const metadata = { title: "Contact" };

export default function ContactPage() {
  return <main style={{ maxWidth: 900, margin: "0 auto", padding: "28px 20px 64px" }}><Card style={{ marginBottom: 14 }}><SectionLabel>CONTACT</SectionLabel><h1 style={{ marginTop: 0, fontSize: 34 }}>Contact CVita</h1><div style={{ color: "#445069", lineHeight: 1.8, fontSize: 15 }}>Use this page as your launch-ready support and sales hub. Replace the placeholder addresses with your real business inboxes before going live.</div></Card><div style={{ display: "grid", gap: 12 }}><Card><SectionLabel>SUPPORT</SectionLabel><div style={{ fontFamily: "monospace", fontSize: 14 }}>support@yourdomain.com</div></Card><Card><SectionLabel>SALES</SectionLabel><div style={{ fontFamily: "monospace", fontSize: 14 }}>sales@yourdomain.com</div></Card><Card><SectionLabel>OPERATIONS</SectionLabel><div style={{ fontFamily: "monospace", fontSize: 14 }}>Riyadh, Saudi Arabia</div></Card></div></main>;
}
