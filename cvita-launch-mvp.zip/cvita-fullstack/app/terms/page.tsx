import { Card, SectionLabel } from "@/components/ui";

export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return <main style={{ maxWidth: 900, margin: "0 auto", padding: "28px 20px 64px" }}><Card><SectionLabel>LEGAL</SectionLabel><h1 style={{ marginTop: 0, fontSize: 34 }}>Terms of Service</h1><div style={{ color: "#445069", lineHeight: 1.8, fontSize: 15 }}>Users are responsible for the accuracy of the content they publish, including career claims, portfolio items, patents, and knowledge products. You must have the rights to sell any uploaded material. Subscription fees are billed in advance. Marketplace earnings, refunds, moderation, and recruiter usage are subject to platform policy and local law. Replace this starter text with a real policy before launch.</div></Card></main>;
}
