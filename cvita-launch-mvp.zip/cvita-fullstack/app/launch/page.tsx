import { Card, SectionLabel, Badge } from "@/components/ui";
import { T } from "@/components/theme";

const groups = [
  { title: "Before you deploy", items: ["Buy your domain and set APP_URL/NEXT_PUBLIC_APP_URL", "Set production Postgres DATABASE_URL", "Create Stripe prices and fill all .env values", "Run prisma migrate deploy on production database"] },
  { title: "Before you take money", items: ["Replace placeholder support and sales emails", "Write refund policy for subscriptions and digital products", "Connect Stripe webhook in production", "Test upgrade, downgrade, cancel, and failed-card flows"] },
  { title: "Before you onboard real users", items: ["Remove demo accounts from production", "Add email verification and password reset", "Add file upload storage and thumbnails", "Set up monitoring, backups, and error tracking"] }
];

export const metadata = { title: "Launch Checklist" };

export default function LaunchPage() {
  return <main style={{ maxWidth: 980, margin: "0 auto", padding: "28px 20px 64px" }}><Card style={{ marginBottom: 16 }}><SectionLabel>LAUNCH READINESS</SectionLabel><h1 style={{ marginTop: 0, fontSize: 34 }}>What is left before you publish this and start charging</h1><div style={{ color: T.mid, lineHeight: 1.7 }}>The app is much closer to launch now, but this page makes the remaining operational work obvious so you do not confuse working code with business readiness.</div><div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}><Badge label="Code: MVP-ready" color={T.green} bg={T.greenBg} /><Badge label="Ops: still needs work" color={T.gold} bg={T.goldBg} /><Badge label="Compliance: do not skip" color={T.red} bg={T.redBg} /></div></Card>{groups.map((group) => <Card key={group.title} style={{ marginBottom: 14 }}><SectionLabel>{group.title.toUpperCase()}</SectionLabel><ul style={{ margin: 0, paddingLeft: 18, color: T.mid, lineHeight: 1.8 }}>{group.items.map((item) => <li key={item}>{item}</li>)}</ul></Card>)}</main>;
}
