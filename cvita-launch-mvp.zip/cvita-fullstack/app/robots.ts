import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || "http://localhost:3000";
  return {
    rules: [
      { userAgent: "*", allow: ["/", "/pricing", "/market", "/jobs", "/u/"], disallow: ["/dashboard", "/seller", "/recruiter", "/agents", "/api/"] }
    ],
    sitemap: `${base}/sitemap.xml`
  };
}
