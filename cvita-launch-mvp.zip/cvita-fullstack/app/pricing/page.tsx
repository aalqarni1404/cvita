import { Card, SectionLabel } from "@/components/ui";
import { PricingClient } from "@/components/client/PricingClient";
import { getCurrentUser } from "@/lib/auth";

const plans = [
  { name: "Free", price: "$0", points: ["Basic CV", "2 AI runs", "Watermarked export"] },
  { name: "Pro", price: "$15", points: ["All CV sections", "20 AI runs", "Marketplace selling"] },
  { name: "Creator", price: "$29", points: ["92% creator share", "50 AI runs", "Custom domain"] },
  { name: "Enterprise", price: "$99", points: ["Recruiter portal", "API access", "Team dashboard"] }
];

export default async function PricingPage() {
  const user = await getCurrentUser();
  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: 24 }}>
      <div style={{ textAlign: "center", marginBottom: 24 }}>
        <SectionLabel>PRICING</SectionLabel>
        <h1 style={{ margin: 0, fontSize: 40 }}>Simple pricing. Stripe-ready backend path included.</h1>
        <p style={{ color: "#445069", marginTop: 10 }}>Buttons now call protected billing endpoints. Without Stripe keys, they return an honest stub response instead of fake success.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 14 }}>
        {plans.map((plan) => (
          <Card key={plan.name}>
            <div style={{ fontFamily: "monospace", fontWeight: 700, marginBottom: 8 }}>{plan.name}</div>
            <div style={{ fontSize: 36, fontWeight: 900, marginBottom: 12 }}>{plan.price}<span style={{ fontSize: 14, color: "#8694b0" }}>/mo</span></div>
            {plan.points.map((point) => <div key={point} style={{ padding: "6px 0", borderBottom: "1px solid #e2e6f0", fontSize: 14 }}>{point}</div>)}
          </Card>
        ))}
      </div>
      <PricingClient isAuthed={!!user} />
    </main>
  );
}
