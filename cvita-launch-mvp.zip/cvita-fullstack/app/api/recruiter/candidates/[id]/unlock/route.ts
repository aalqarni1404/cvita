import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRecruiter } from "@/lib/auth";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const recruiter = await requireRecruiter();
    if (recruiter.recruiterCredits <= 0) return NextResponse.json({ error: "No recruiter credits left" }, { status: 402 });
    const { id } = await params;
    const candidate = await prisma.profile.findUnique({ where: { id }, include: { user: true } });
    if (!candidate) return NextResponse.json({ error: "Candidate not found" }, { status: 404 });
    const existing = await prisma.candidateUnlock.findUnique({ where: { recruiterId_candidateId: { recruiterId: recruiter.id, candidateId: id } } });
    if (!existing) {
      await prisma.$transaction([
        prisma.candidateUnlock.create({ data: { recruiterId: recruiter.id, candidateId: id } }),
        prisma.user.update({ where: { id: recruiter.id }, data: { recruiterCredits: { decrement: 1 } } })
      ]);
    }
    return NextResponse.json({ ok: true, contact: { email: candidate.user.email, linkedIn: `https://linkedin.com/in/${candidate.user.fullName.toLowerCase().replace(/\s+/g, "-")}` } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Bad request";
    return NextResponse.json({ error: message === "FORBIDDEN" ? "Forbidden" : message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: message === "FORBIDDEN" ? 403 : message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
