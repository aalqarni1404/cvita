import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const tags = searchParams.getAll("tag");
  const recruiter = await getCurrentUser();
  const profiles = await prisma.profile.findMany({ include: { user: { select: { id: true, email: true, fullName: true } }, hashtags: true }, where: { visible: true } });
  const filtered = tags.length === 0 ? profiles : profiles.filter((profile) => tags.every((tag) => profile.hashtags.map((h) => h.label.toLowerCase()).includes(tag.toLowerCase())));
  const unlocks = recruiter && (recruiter.role === "RECRUITER" || recruiter.role === "ADMIN") ? await prisma.candidateUnlock.findMany({ where: { recruiterId: recruiter.id } }) : [];
  const unlockedIds = new Set(unlocks.map((u) => u.candidateId));
  return NextResponse.json(filtered.map((profile) => ({ ...profile, unlocked: unlockedIds.has(profile.id), contact: unlockedIds.has(profile.id) ? { email: profile.user.email, linkedIn: `https://linkedin.com/in/${profile.user.fullName.toLowerCase().replace(/\s+/g, "-")}` } : null })));
}
