import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { cartItemSchema } from "@/lib/validators";

export async function GET() {
  try {
    const user = await requireUser();
    const items = await prisma.cartItem.findMany({ where: { userId: user.id }, include: { product: { include: { creator: true, tags: true } } } });
    return NextResponse.json({ items, totalCents: items.reduce((sum, item) => sum + item.product.priceCents, 0) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = cartItemSchema.parse(await request.json());
    const item = await prisma.cartItem.upsert({ where: { userId_productId: { userId: user.id, productId: body.productId } }, update: {}, create: { userId: user.id, productId: body.productId }, include: { product: true } });
    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireUser();
    const productId = new URL(request.url).searchParams.get("productId");
    if (!productId) return NextResponse.json({ error: "productId is required" }, { status: 400 });
    await prisma.cartItem.deleteMany({ where: { userId: user.id, productId } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
