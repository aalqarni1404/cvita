import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { checkoutSchema } from "@/lib/validators";

export async function POST(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = checkoutSchema.parse(await request.json().catch(() => ({})));
    const cartItems = await prisma.cartItem.findMany({ where: body.productIds?.length ? { userId: user.id, productId: { in: body.productIds } } : { userId: user.id }, include: { product: true } });
    if (cartItems.length === 0) return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
    const totalCents = cartItems.reduce((sum, item) => sum + item.product.priceCents, 0);
    const order = await prisma.order.create({ data: { buyerId: user.id, totalCents, items: { create: cartItems.map((item) => ({ productId: item.productId, unitPriceCents: item.product.priceCents })) } }, include: { items: true } });
    await prisma.cartItem.deleteMany({ where: { id: { in: cartItems.map((item) => item.id) } } });
    return NextResponse.json({ orderId: order.id, totalCents, itemCount: order.items.length });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
