import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type");
  const sort = searchParams.get("sort") || "popular";

  const products = await prisma.product.findMany({
    where: type && type !== "All" ? { type: type as never } : undefined,
    include: { creator: true, tags: true },
    orderBy: sort === "low" ? { priceCents: "asc" } : sort === "high" ? { priceCents: "desc" } : { students: "desc" }
  });

  return NextResponse.json(products);
}
