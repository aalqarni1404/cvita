import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { productEditorSchema } from "@/lib/validators";

export async function GET() {
  try {
    const user = await requireUser();
    const products = await prisma.product.findMany({
      where: { creatorId: user.id },
      include: { tags: true },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ products });
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: "Failed to load products" }, { status: 400 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = productEditorSchema.parse(await request.json());
    const product = await prisma.product.create({
      data: {
        creatorId: user.id,
        title: body.title,
        description: body.description,
        type: body.type,
        priceCents: body.priceCents,
        published: body.published,
        tags: { create: body.tags.map((label) => ({ label: label.replace(/^#/, "") })) }
      },
      include: { tags: true }
    });
    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: "Invalid product", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = productEditorSchema.parse(await request.json());
    if (!body.id) return NextResponse.json({ error: "Product id required" }, { status: 400 });

    const existing = await prisma.product.findFirst({ where: { id: body.id, creatorId: user.id } });
    if (!existing) return NextResponse.json({ error: "Product not found" }, { status: 404 });

    const product = await prisma.$transaction(async (tx) => {
      await tx.product.update({
        where: { id: body.id },
        data: {
          title: body.title,
          description: body.description,
          type: body.type,
          priceCents: body.priceCents,
          published: body.published
        }
      });
      await tx.productTag.deleteMany({ where: { productId: body.id } });
      if (body.tags.length) {
        await tx.productTag.createMany({ data: body.tags.map((label) => ({ productId: body.id!, label: label.replace(/^#/, "") })) });
      }
      return tx.product.findUnique({ where: { id: body.id }, include: { tags: true } });
    });

    return NextResponse.json(product);
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: "Could not update product", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}
