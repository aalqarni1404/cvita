import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { AI_RESULTS } from "@/lib/ai";
import { runAiSchema } from "@/lib/validators";
import { requireUser } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    const body = runAiSchema.parse(await request.json());
    const user = await requireUser();
    if (user.aiCredits <= 0) return NextResponse.json({ error: "No credits left" }, { status: 402 });
    const run = await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: user.id }, data: { aiCredits: { decrement: 1 } } });
      return tx.aiAgentRun.create({ data: { userId: user.id, agentId: body.agentId, output: AI_RESULTS[body.agentId] } });
    });
    const refreshed = await prisma.user.findUnique({ where: { id: user.id }, select: { aiCredits: true } });
    return NextResponse.json({ runId: run.id, result: run.output, aiCreditsRemaining: refreshed?.aiCredits ?? 0 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Invalid request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
