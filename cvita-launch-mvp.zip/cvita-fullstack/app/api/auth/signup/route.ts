import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { signupSchema } from "@/lib/validators";
import { createSession } from "@/lib/auth";

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || `user-${Date.now()}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = signupSchema.parse(await request.json());
    const exists = await prisma.user.findUnique({ where: { email: body.email } });
    if (exists) return NextResponse.json({ error: "Email already in use" }, { status: 409 });
    const passwordHash = await bcrypt.hash(body.password, 10);
    const baseSlug = slugify(body.fullName);
    const slugTaken = await prisma.profile.findUnique({ where: { slug: baseSlug } });
    const slug = slugTaken ? `${baseSlug}-${Math.floor(Math.random() * 1000)}` : baseSlug;
    const user = await prisma.user.create({
      data: {
        email: body.email,
        fullName: body.fullName,
        role: body.role,
        passwordHash,
        recruiterCredits: body.role === "RECRUITER" ? 3 : 0,
        profile: body.role === "PROFESSIONAL" ? { create: { slug, title: "New Professional", location: "Remote", status: "🟢 Open to Work", summary: "Tell your story here." } } : undefined
      },
      select: { id: true, email: true, fullName: true, role: true, plan: true, aiCredits: true, recruiterCredits: true }
    });
    await createSession(user.id);
    return NextResponse.json(user, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Invalid request", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}
