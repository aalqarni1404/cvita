import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
export async function GET() { const user = await getCurrentUser(); return NextResponse.json({ user: user ? { id: user.id, email: user.email, fullName: user.fullName, role: user.role, plan: user.plan, aiCredits: user.aiCredits, recruiterCredits: user.recruiterCredits, profile: user.profile } : null }); }
