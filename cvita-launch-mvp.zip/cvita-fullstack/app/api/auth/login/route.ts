import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession, verifyPassword } from "@/lib/auth";
import { loginSchema } from "@/lib/validators";

export async function POST(request: NextRequest) {
  try {
    const body = loginSchema.parse(await request.json());
    const user = await prisma.user.findUnique({ where: { email: body.email }, include: { profile: true } });
    if (!user || !(await verifyPassword(body.password, user.passwordHash))) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    await createSession(user.id);
    return NextResponse.json({ id: user.id, email: user.email, fullName: user.fullName, role: user.role, plan: user.plan, aiCredits: user.aiCredits, recruiterCredits: user.recruiterCredits, hasProfile: !!user.profile });
  } catch (error) {
    return NextResponse.json({ error: "Invalid request", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}
