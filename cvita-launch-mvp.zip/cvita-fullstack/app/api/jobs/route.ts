import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  const jobs = await prisma.job.findMany({ include: { tags: true, applications: user ? { where: { userId: user.id }, select: { id: true } } : false, savedBy: user ? { where: { userId: user.id }, select: { id: true } } : false }, where: { active: true }, orderBy: { createdAt: "desc" } });
  return NextResponse.json(jobs.map((job) => ({ ...job, applied: Array.isArray(job.applications) ? job.applications.length > 0 : false, saved: Array.isArray(job.savedBy) ? job.savedBy.length > 0 : false })));
}
