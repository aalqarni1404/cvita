import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const job = await prisma.job.findUnique({ where: { id } });
    if (!job) return NextResponse.json({ error: "Job not found" }, { status: 404 });
    const existing = await prisma.application.findUnique({ where: { userId_jobId: { userId: user.id, jobId: id } } });
    const application = existing ?? await prisma.application.create({ data: { userId: user.id, jobId: id } });
    if (!existing) await prisma.job.update({ where: { id }, data: { applicants: { increment: 1 } } });
    return NextResponse.json(application, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error && error.message === "UNAUTHORIZED" ? "Unauthorized" : "Bad request" }, { status: error instanceof Error && error.message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
