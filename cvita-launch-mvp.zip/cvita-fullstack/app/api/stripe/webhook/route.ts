import { headers } from "next/headers";
import { NextResponse } from "next/server";
import Stripe from "stripe";
import { BillingInterval, Plan } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getWebhookSecret, stripe } from "@/lib/stripe";

export async function POST(request: Request) {
  if (!stripe) return NextResponse.json({ error: "Stripe not configured" }, { status: 500 });
  const signature = (await headers()).get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Missing stripe-signature" }, { status: 400 });

  const payload = await request.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(payload, signature, getWebhookSecret());
  } catch (error) {
    return NextResponse.json({ error: `Webhook signature verification failed: ${error instanceof Error ? error.message : "unknown"}` }, { status: 400 });
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      if (session.mode === "subscription") {
        const userId = session.metadata?.userId;
        const planCode = session.metadata?.planCode as Plan | undefined;
        const interval = (session.metadata?.interval as BillingInterval | undefined) || BillingInterval.MONTH;
        if (userId && planCode && typeof session.subscription === "string") {
          const planRow = await prisma.subscriptionPlan.findUnique({ where: { code: planCode } });
          if (planRow) {
            await prisma.user.update({ where: { id: userId }, data: { plan: planCode, aiCredits: planRow.aiCredits, recruiterCredits: planRow.recruiterCredits } });
            await prisma.subscription.upsert({
              where: { stripeSubscriptionId: session.subscription },
              update: { status: "active", interval },
              create: { userId, subscriptionPlanId: planRow.id, stripeSubscriptionId: session.subscription, interval, status: "active" }
            });
          }
        }
      }
      break;
    }
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      const existing = await prisma.subscription.findUnique({ where: { stripeSubscriptionId: subscription.id } });
      if (existing) {
        const active = subscription.status === "active" || subscription.status === "trialing";
        const item = subscription.items.data[0];
        await prisma.subscription.update({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: active ? "active" : subscription.status,
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
            currentPeriodStart: item?.current_period_start ? new Date(item.current_period_start * 1000) : undefined,
            currentPeriodEnd: item?.current_period_end ? new Date(item.current_period_end * 1000) : undefined
          }
        });
        if (!active) {
          await prisma.user.update({ where: { id: existing.userId }, data: { plan: Plan.FREE, aiCredits: 2, recruiterCredits: 0 } });
        }
      }
      break;
    }
    default:
      break;
  }

  return NextResponse.json({ received: true });
}
