import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { ensureStripeCustomer, getBaseUrl, stripe } from "@/lib/stripe";

export async function POST() {
  try {
    const user = await requireUser();
    if (!stripe) return NextResponse.json({ mode: "stub", message: "Stripe billing portal is not configured yet." });
    const customer = await ensureStripeCustomer(user);
    const session = await stripe.billingPortal.sessions.create({ customer, return_url: `${getBaseUrl()}/pricing` });
    return NextResponse.json({ url: session.url });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Bad request";
    return NextResponse.json({ error: message === "UNAUTHORIZED" ? "Unauthorized" : message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
