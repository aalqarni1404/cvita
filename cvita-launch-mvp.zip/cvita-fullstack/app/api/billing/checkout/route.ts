import { NextRequest, NextResponse } from "next/server";
import { BillingInterval, Plan } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ensureStripeCustomer, getBaseUrl, stripe } from "@/lib/stripe";
import { APP_PLANS } from "@/lib/plans";

const schema = z.object({
  plan: z.enum(["PRO", "CREATOR", "ENTERPRISE"]),
  interval: z.enum(["MONTH", "YEAR"]).default("MONTH")
});

export async function POST(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = schema.parse(await request.json());
    const selected = APP_PLANS[body.plan as Plan];
    const planRow = await prisma.subscriptionPlan.findUnique({ where: { code: body.plan as Plan } });

    if (!selected || !planRow) {
      return NextResponse.json({ error: "Unknown plan" }, { status: 400 });
    }

    const livePrice = body.interval === "YEAR" ? planRow.stripePriceYearly : planRow.stripePriceMonthly;
    if (!stripe || !livePrice) {
      return NextResponse.json({
        mode: "stub",
        message: "Stripe is not configured yet. Add STRIPE_SECRET_KEY and the matching price IDs in .env.",
        selectedPlan: body.plan,
        interval: body.interval,
        fallbackAmountCents: body.interval === "YEAR" ? selected.yearly ?? selected.monthly * 12 : selected.monthly
      });
    }

    const customerId = await ensureStripeCustomer(user);
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: livePrice, quantity: 1 }],
      metadata: { userId: user.id, planCode: body.plan, interval: body.interval },
      success_url: `${getBaseUrl()}/pricing?checkout=success`,
      cancel_url: `${getBaseUrl()}/pricing?checkout=cancelled`
    });

    await prisma.subscription.upsert({
      where: { stripeSubscriptionId: typeof session.subscription === "string" ? session.subscription : `pending_${session.id}` },
      update: { status: "pending", interval: body.interval as BillingInterval },
      create: {
        userId: user.id,
        subscriptionPlanId: planRow.id,
        interval: body.interval as BillingInterval,
        status: "pending",
        stripeSubscriptionId: typeof session.subscription === "string" ? session.subscription : `pending_${session.id}`
      }
    });

    return NextResponse.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Bad request";
    return NextResponse.json({ error: message === "UNAUTHORIZED" ? "Unauthorized" : message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
