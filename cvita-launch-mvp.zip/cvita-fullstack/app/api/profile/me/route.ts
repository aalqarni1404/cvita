import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { updateProfileSchema } from "@/lib/validators";

const profileInclude = {
  user: { select: { id: true, fullName: true, email: true, plan: true, aiCredits: true, recruiterCredits: true, role: true } },
  experiences: true,
  hashtags: true,
  patents: true,
  ventures: true
} as const;

export async function GET() {
  try {
    const user = await requireUser();
    const profile = await prisma.profile.findUnique({ where: { userId: user.id }, include: profileInclude });
    if (!profile) return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    return NextResponse.json(profile);
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: "Bad request", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const user = await requireUser();
    const body = updateProfileSchema.parse(await request.json());

    const profile = await prisma.$transaction(async (tx) => {
      const updated = await tx.profile.update({
        where: { userId: user.id },
        data: {
          ...(body.slug !== undefined ? { slug: body.slug } : {}),
          ...(body.title !== undefined ? { title: body.title } : {}),
          ...(body.location !== undefined ? { location: body.location } : {}),
          ...(body.status !== undefined ? { status: body.status } : {}),
          ...(body.summary !== undefined ? { summary: body.summary } : {})
        }
      });

      if (body.hashtags) {
        await tx.hashtag.deleteMany({ where: { profileId: updated.id } });
        if (body.hashtags.length) {
          await tx.hashtag.createMany({
            data: [...new Set(body.hashtags.map((tag) => tag.replace(/^#/, "").trim()).filter(Boolean))].map((label) => ({ profileId: updated.id, label }))
          });
        }
      }

      if (body.experiences) {
        await tx.experience.deleteMany({ where: { profileId: updated.id } });
        if (body.experiences.length) {
          await tx.experience.createMany({
            data: body.experiences.map((item) => ({ profileId: updated.id, title: item.title, organization: item.organization, period: item.period, bullets: item.bullets }))
          });
        }
      }

      if (body.patents) {
        await tx.patent.deleteMany({ where: { profileId: updated.id } });
        if (body.patents.length) {
          await tx.patent.createMany({
            data: body.patents.map((item) => ({ profileId: updated.id, title: item.title, number: item.number, status: item.status }))
          });
        }
      }

      if (body.ventures) {
        await tx.venture.deleteMany({ where: { profileId: updated.id } });
        if (body.ventures.length) {
          await tx.venture.createMany({
            data: body.ventures.map((item) => ({ profileId: updated.id, name: item.name, role: item.role, stage: item.stage, revenue: item.revenue, teamSize: item.teamSize }))
          });
        }
      }

      return tx.profile.findUnique({ where: { id: updated.id }, include: profileInclude });
    });

    return NextResponse.json(profile);
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (error instanceof Error && 'Unique constraint' in error.message) return NextResponse.json({ error: "Slug already taken" }, { status: 409 });
    return NextResponse.json({ error: "Invalid request", detail: error instanceof Error ? error.message : "unknown" }, { status: 400 });
  }
}
