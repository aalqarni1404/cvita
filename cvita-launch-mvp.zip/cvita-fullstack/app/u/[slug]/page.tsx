import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Badge, Btn, Card, SectionLabel } from "@/components/ui";
import { T } from "@/components/theme";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const profile = await prisma.profile.findUnique({ where: { slug }, include: { user: true } });
  if (!profile) return { title: "Profile not found" };
  return {
    title: `${profile.user.fullName} · ${profile.title} · CVita`,
    description: profile.summary ?? `${profile.user.fullName} on CVita`
  };
}

export default async function PublicProfilePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const profile = await prisma.profile.findUnique({
    where: { slug },
    include: {
      user: true,
      hashtags: true,
      experiences: true,
      patents: true,
      ventures: true
    }
  });

  if (!profile || !profile.visible) notFound();

  const products = await prisma.product.findMany({
    where: { creatorId: profile.userId, published: true },
    include: { tags: true },
    orderBy: [{ students: "desc" }, { createdAt: "desc" }]
  });

  return (
    <main style={{ maxWidth: 1040, margin: "0 auto", padding: "28px 20px 64px" }}>
      <Card style={{ marginBottom: 16, background: `linear-gradient(135deg,${T.dark},#1e2d45)`, color: "#e2e8f0" }}>
        <SectionLabel>PUBLIC PROFILE</SectionLabel>
        <h1 style={{ margin: "0 0 8px", fontSize: 40 }}>{profile.user.fullName}</h1>
        <div style={{ color: "#94a3b8", marginBottom: 10 }}>{profile.title} · {profile.location}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
          <Badge label={profile.status} color={T.green} bg={T.greenBg} />
          <Badge label={`Career score ${profile.careerScore}`} color={T.gold} bg={T.goldBg} />
          <Badge label={profile.user.plan} color={T.blue} bg={T.blueBg} />
        </div>
        <p style={{ margin: 0, color: "#cbd5e1", lineHeight: 1.7, maxWidth: 760 }}>{profile.summary}</p>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        <div>
          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>EXPERIENCE</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {profile.experiences.map((item) => (
                <div key={item.id} style={{ paddingBottom: 12, borderBottom: `1px solid ${T.border}` }}>
                  <div style={{ fontWeight: 700, fontSize: 18 }}>{item.title}</div>
                  <div style={{ color: T.mid, marginBottom: 6 }}>{item.organization} · {item.period}</div>
                  <ul style={{ margin: 0, paddingLeft: 18, color: T.mid, lineHeight: 1.7 }}>
                    {(item.bullets as string[]).map((bullet) => <li key={bullet}>{bullet}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <SectionLabel>KNOWLEDGE PRODUCTS</SectionLabel>
            {products.length === 0 ? <div style={{ color: T.mute }}>No public products yet.</div> : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 12 }}>
                {products.map((product) => (
                  <div key={product.id} style={{ border: `1px solid ${T.border}`, borderRadius: 12, padding: 14, background: T.bg }}>
                    <div style={{ fontFamily: "monospace", fontSize: 11, color: T.mute, marginBottom: 6 }}>{product.type}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>{product.title}</div>
                    <div style={{ color: T.mid, fontSize: 14, lineHeight: 1.6, marginBottom: 10 }}>{product.description}</div>
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
                      {product.tags.map((tag) => <Badge key={tag.id} label={`#${tag.label}`} color={T.blue} bg={T.blueBg} />)}
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ fontFamily: "monospace", fontWeight: 700 }}>${(product.priceCents / 100).toFixed(2)}</div>
                      <Btn href="/market">View in marketplace</Btn>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <div>
          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>HASHTAGS</SectionLabel>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {profile.hashtags.map((tag) => <Badge key={tag.id} label={`#${tag.label}`} color={T.gold} bg={T.goldBg} />)}
            </div>
          </Card>

          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>PATENTS</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {profile.patents.length === 0 ? <div style={{ color: T.mute }}>No patents listed.</div> : profile.patents.map((patent) => (
                <div key={patent.id} style={{ border: `1px solid ${T.border}`, borderRadius: 10, padding: 12 }}>
                  <div style={{ fontWeight: 700 }}>{patent.title}</div>
                  <div style={{ color: T.mid, fontSize: 13 }}>{patent.number}</div>
                  <Badge label={patent.status} color={T.green} bg={T.greenBg} />
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <SectionLabel>VENTURES</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {profile.ventures.length === 0 ? <div style={{ color: T.mute }}>No ventures listed.</div> : profile.ventures.map((venture) => (
                <div key={venture.id} style={{ border: `1px solid ${T.border}`, borderRadius: 10, padding: 12 }}>
                  <div style={{ fontWeight: 700 }}>{venture.name}</div>
                  <div style={{ color: T.mid, fontSize: 13 }}>{venture.role} · {venture.stage}</div>
                  <div style={{ color: T.green, fontFamily: "monospace", fontSize: 12 }}>{venture.revenue} · team {venture.teamSize}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </main>
  );
}
