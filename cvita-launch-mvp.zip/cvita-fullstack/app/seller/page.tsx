import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { SellerClient } from "@/components/client/SellerClient";

export const metadata = { title: "Seller Studio · CVita" };

export default async function SellerPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/?auth=required&next=/seller");
  const products = await prisma.product.findMany({
    where: { creatorId: user.id },
    include: { tags: true },
    orderBy: { createdAt: "desc" }
  });
  return <SellerClient initialProducts={products} />;
}
