export const AI_RESULTS: Record<string, string> = {
  cv: `REWRITES:\n• 'Led' component library redesign → design debt ↓40%, sprint velocity ↑2.3×\n• Drove 3 product launches with 12 cross-functional PMs\n• Mentored 4 designers → team output quality ↑35%\n\nKEYWORDS ADDED: design systems · cross-functional · OKRs\nSCORE: 74 → 88 (+14 pts) ↑`,
  hashtag: `ADD NOW:\n#UXLeadership — 340% YoY recruiter search growth\n#DesignTokens — high signal, low competition\n#AIDesign — fast-growing niche\n\nKEEP: #DesignSystems · #OpenToWork · #Figma\nREMOVE: #Designer — too broad, poor signal\n\nVISIBILITY UPLIFT: +64% estimated ↑`,
  price: `UX Masterclass: $49 → $79 (+$5,580/yr)\nDesign Deck: $19 → $29 (+$3,120/yr)\n\nTOTAL ANNUAL UPLIFT: +$8,700 💰`,
  patent: `ABSTRACT: A system for dynamically adapting UI layouts based on real-time user behaviour signals and accessibility requirements...\n\nCLAIM 1: A method comprising collecting interaction signals, assessing WCAG compliance, and propagating token changes across platforms.`,
  outreach: `SUBJECT: Your #DesignSystems work caught my eye\n\nHi Alex — your systems-thinking background is exactly what our team needs. Open to a 20-minute call this week?`,
  roadmap: `TARGET: CPO at Series B fintech — 3 years\n\nQ1: Apply to Head of Design at 3 Series B companies\nQ2: Own a product OKR\nQ3: Ship a metric-driven feature solo\nQ4: Manage a team of 4+`
};
