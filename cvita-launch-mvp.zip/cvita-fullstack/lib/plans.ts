import { Plan } from "@prisma/client";

export const APP_PLANS: Record<Plan, { name: string; description: string; monthly: number; yearly?: number; aiCredits: number; recruiterCredits: number }> = {
  FREE: { name: "Free", description: "Basic CV and limited AI", monthly: 0, aiCredits: 2, recruiterCredits: 0 },
  PRO: { name: "Pro", description: "Professional creator plan", monthly: 1500, yearly: 15000, aiCredits: 20, recruiterCredits: 0 },
  CREATOR: { name: "Creator", description: "Higher take rate and more AI", monthly: 2900, yearly: 29000, aiCredits: 50, recruiterCredits: 0 },
  ENTERPRISE: { name: "Enterprise", description: "Recruiting and API access", monthly: 9900, yearly: 99000, aiCredits: 9999, recruiterCredits: 50 }
};
