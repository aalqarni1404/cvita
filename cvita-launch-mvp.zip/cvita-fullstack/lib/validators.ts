import { z } from "zod";

export const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(2),
  role: z.enum(["PROFESSIONAL", "RECRUITER"]).default("PROFESSIONAL")
});

export const loginSchema = z.object({ email: z.string().email(), password: z.string().min(8) });

export const experienceInputSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(2),
  organization: z.string().min(2),
  period: z.string().min(2),
  bullets: z.array(z.string().min(2)).min(1)
});

export const patentInputSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(2),
  number: z.string().min(2),
  status: z.string().min(2)
});

export const ventureInputSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2),
  role: z.string().min(2),
  stage: z.string().min(2),
  revenue: z.string().min(1),
  teamSize: z.number().int().min(1).max(100000)
});

export const updateProfileSchema = z.object({
  slug: z.string().min(3).max(40).regex(/^[a-z0-9-]+$/).optional(),
  title: z.string().min(2).optional(),
  location: z.string().min(2).optional(),
  status: z.string().min(2).optional(),
  summary: z.string().min(10).optional(),
  hashtags: z.array(z.string().min(1)).optional(),
  experiences: z.array(experienceInputSchema).optional(),
  patents: z.array(patentInputSchema).optional(),
  ventures: z.array(ventureInputSchema).optional()
});

export const runAiSchema = z.object({ agentId: z.enum(["cv", "hashtag", "price", "patent", "outreach", "roadmap"]) });
export const cartItemSchema = z.object({ productId: z.string().min(1) });
export const checkoutSchema = z.object({ productIds: z.array(z.string().min(1)).min(1).optional() });

export const productEditorSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(3),
  description: z.string().min(20),
  type: z.enum(["COURSE", "TEMPLATE", "EBOOK", "WORKSHOP", "LECTURE"]),
  priceCents: z.number().int().min(100),
  tags: z.array(z.string().min(1)).max(8).default([]),
  published: z.boolean().default(true)
});
