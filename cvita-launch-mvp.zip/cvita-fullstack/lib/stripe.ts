import Stripe from "stripe";
import { prisma } from "@/lib/prisma";

export const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2025-02-24.acacia" })
  : null;

export function getBaseUrl() {
  return process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || "http://localhost:3000";
}

export function getWebhookSecret() {
  return process.env.STRIPE_WEBHOOK_SECRET || "";
}

export async function ensureStripeCustomer(user: { id: string; email: string; fullName: string; stripeCustomerId?: string | null }) {
  if (!stripe) throw new Error("STRIPE_NOT_CONFIGURED");
  if (user.stripeCustomerId) return user.stripeCustomerId;
  const customer = await stripe.customers.create({ email: user.email, name: user.fullName, metadata: { userId: user.id } });
  await prisma.user.update({ where: { id: user.id }, data: { stripeCustomerId: customer.id } });
  return customer.id;
}
