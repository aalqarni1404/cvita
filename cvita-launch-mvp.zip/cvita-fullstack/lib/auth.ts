import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { randomBytes, createHash, timingSafeEqual } from "crypto";
import bcrypt from "bcryptjs";

export const SESSION_COOKIE = "cvita_session";
const SESSION_DAYS = 14;

function sha256(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  const tokenHash = sha256(token);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await prisma.session.create({ data: { userId, token: tokenHash, expiresAt } });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
    path: "/"
  });
}

export async function clearSession() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await prisma.session.deleteMany({ where: { token: sha256(token) } });
  store.set(SESSION_COOKIE, "", { expires: new Date(0), path: "/" });
}

export async function getCurrentUser() {
  const store = await cookies();
  const rawToken = store.get(SESSION_COOKIE)?.value;
  if (!rawToken) return null;
  const tokenHash = sha256(rawToken);
  const session = await prisma.session.findUnique({
    where: { token: tokenHash },
    include: { user: { include: { profile: { include: { hashtags: true } }, subscriptions: { where: { status: "active" }, include: { subscriptionPlan: true }, orderBy: { createdAt: "desc" }, take: 1 } } } }
  });
  if (!session || session.expiresAt < new Date()) {
    await prisma.session.deleteMany({ where: { token: tokenHash } });
    return null;
  }
  return session.user;
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}

export async function requireRecruiter() {
  const user = await requireUser();
  if (user.role !== "RECRUITER" && user.role !== "ADMIN") throw new Error("FORBIDDEN");
  return user;
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export function safeTokenEqual(a: string, b: string) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
