import Link from "next/link";
import { CSSProperties, ReactNode } from "react";
import { T } from "./theme";

export function Btn({ children, href, style, ...props }: { children: ReactNode; href?: string; style?: CSSProperties } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  if (href) {
    return (
      <Link href={href} style={{
        display: "inline-block",
        background: `linear-gradient(135deg,${T.blue},#3b82f6)`,
        color: "#fff",
        borderRadius: 8,
        padding: "10px 16px",
        fontFamily: "monospace",
        fontSize: 12,
        fontWeight: "bold",
        textDecoration: "none",
        ...style
      }}>
        {children}
      </Link>
    );
  }

  return (
    <button
      {...props}
      style={{
        background: `linear-gradient(135deg,${T.blue},#3b82f6)`,
        color: "#fff",
        border: "none",
        borderRadius: 8,
        padding: "10px 16px",
        fontFamily: "monospace",
        fontSize: 12,
        fontWeight: "bold",
        cursor: "pointer",
        ...style
      }}
    >
      {children}
    </button>
  );
}

export function Card({ children, style }: { children: ReactNode; style?: CSSProperties }) {
  return <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 14, padding: 16, boxShadow: "0 1px 4px rgba(0,0,0,0.05)", ...style }}>{children}</div>;
}

export function Badge({ label, color, bg }: { label: string; color: string; bg: string }) {
  return <span style={{ display: "inline-flex", alignItems: "center", fontFamily: "monospace", fontSize: 10, fontWeight: 700, color, background: bg, border: `1px solid ${color}33`, padding: "3px 8px", borderRadius: 999 }}>{label}</span>;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <div style={{ fontFamily: "monospace", fontSize: 10, color: T.mute, letterSpacing: 2, marginBottom: 10 }}>{children}</div>;
}
