import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";

const nav = [["/","🏠 Home"],["/dashboard","👤 Dashboard"],["/seller","🧾 Seller"],["/market","🛒 Marketplace"],["/jobs","💼 Jobs"],["/recruiter","🔍 Recruiter"],["/agents","🤖 AI Agents"],["/pricing","💳 Pricing"]] as const;

export async function Nav() {
  const user = await getCurrentUser();
  const slug = user?.profile?.slug;
  return <div style={{ position:"sticky", top:0, zIndex:100, display:"flex", alignItems:"center", gap:8, background:"rgba(10,15,30,0.96)", borderBottom:"1px solid #1c2d45", padding:"0 16px", height:56, overflowX:"auto" }}><Link href="/" style={{ color:"#e2e8f0", textDecoration:"none", fontSize:20, fontWeight:900 }}>CV<span style={{ color:"#60a5fa" }}>ita</span></Link>{nav.map(([href,label])=><Link key={href} href={href} style={{ color:"#8aa0bf", textDecoration:"none", padding:"6px 10px", borderRadius:8, fontFamily:"monospace", fontSize:11 }}>{label}</Link>)}{slug && <Link href={`/u/${slug}`} style={{ color:"#60a5fa", textDecoration:"none", padding:"6px 10px", borderRadius:8, fontFamily:"monospace", fontSize:11 }}>🌐 Public profile</Link>}<div style={{ marginLeft:"auto", color:user?"#60a5fa":"#334155", fontFamily:"monospace", fontSize:10 }}>{user ? `${user.fullName} · ${user.role}` : "SIGN IN ON HOME"}</div></div>;
}
