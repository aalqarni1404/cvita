"use client";

import { useEffect, useState, type CSSProperties } from "react";
import { Btn, Card } from "@/components/ui";
import { T } from "@/components/theme";

export function AuthPanel() {
  const [user, setUser] = useState<any>(null);
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [fullName, setFullName] = useState("Founder Example");
  const [role, setRole] = useState("PROFESSIONAL");
  const [email, setEmail] = useState("alex@cvita.dev");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    const r = await fetch("/api/auth/me", { cache: "no-store" });
    const d = await r.json();
    setUser(d.user ?? null);
  }

  useEffect(() => { void load(); }, []);

  async function submit() {
    setLoading(true);
    setError(null);
    const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/signup";
    const payload = mode === "login" ? { email, password } : { email, password, fullName, role };
    const r = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const d = await r.json();
    setLoading(false);
    if (!r.ok) return setError(d.error || d.detail || `${mode} failed`);
    window.location.reload();
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.reload();
  }

  return <Card style={{ background:"#141c2e", border:"1px solid #1c2d45", color:"#e2e8f0", maxWidth:860, margin:"0 auto 22px" }}><div style={{ display:'grid', gridTemplateColumns:user?'1fr auto':'1.3fr 1fr', gap:16, alignItems:'start' }}><div>{user ? <><div style={{ fontSize:22, fontWeight:800, marginBottom:6 }}>{user.fullName}</div><div style={{ color:'#94a3b8', marginBottom:12 }}>{user.email} · {user.role} · {user.plan}</div><div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:10 }}><span style={{ fontFamily:'monospace', fontSize:11, background:T.blueBg, color:T.blue, border:`1px solid ${T.blueBrd}`, padding:'4px 8px', borderRadius:999 }}>AI credits: {user.aiCredits}</span><span style={{ fontFamily:'monospace', fontSize:11, background:T.purpleBg, color:T.purple, border:`1px solid ${T.purpleBrd}`, padding:'4px 8px', borderRadius:999 }}>Recruiter credits: {user.recruiterCredits}</span></div><div style={{ color:'#94a3b8', fontSize:14 }}>You now have a real authenticated account in the starter. Use the dashboard, seller studio, marketplace, and billing flows.</div></> : <><div style={{ display:'flex', gap:8, marginBottom:12 }}><button onClick={()=>setMode('login')} style={mode==='login'?tabOn:tabOff}>Sign in</button><button onClick={()=>setMode('signup')} style={mode==='signup'?tabOn:tabOff}>Create account</button></div><div style={{ fontSize:22, fontWeight:800, marginBottom:6 }}>{mode === 'login' ? 'Sign in' : 'Create your account'}</div><div style={{ color:'#94a3b8', lineHeight:1.6, marginBottom:12 }}>This version supports real signup and login instead of a dead-end landing page.</div><div style={{ display:'grid', gap:8 }}>{mode==='signup' && <><input value={fullName} onChange={e=>setFullName(e.target.value)} placeholder='Full name' style={s}/><select value={role} onChange={e=>setRole(e.target.value)} style={s}><option value='PROFESSIONAL'>Professional</option><option value='RECRUITER'>Recruiter</option></select></>}<div style={{ display:'grid', gridTemplateColumns:'1fr 1fr auto', gap:8 }}><input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email' style={s}/><input value={password} type='password' onChange={e=>setPassword(e.target.value)} placeholder='Password' style={s}/><Btn onClick={submit}>{loading ? 'Working…' : mode === 'login' ? 'Sign in' : 'Create'}</Btn></div></div>{error && <div style={{ color:'#fca5a5', fontFamily:'monospace', fontSize:11, marginTop:10 }}>{error}</div>}</>}</div><div style={{ minWidth:230 }}><div style={{ fontFamily:'monospace', fontSize:10, color:'#64748b', marginBottom:8 }}>DEMO ACCOUNTS</div>{[['alex@cvita.dev','password123'],['james@cvita.dev','password123'],['recruiter@cvita.dev','password123']].map(([e,p])=><div key={e} onClick={()=>{setMode('login');setEmail(e);setPassword(p)}} style={{ cursor:'pointer', background:'#0f1628', border:'1px solid #1c2d45', borderRadius:10, padding:10, marginBottom:8 }}><div style={{ fontFamily:'monospace', fontSize:10, color:'#94a3b8' }}>{e}</div></div>)}{user && <Btn onClick={logout} style={{ width:'100%', background:'transparent', border:'1px solid #2d4060', color:'#e2e8f0' }}>Logout</Btn>}</div></div></Card>;
}

const s:CSSProperties={ background:'#0f1628', border:'1px solid #2d4060', color:'#e2e8f0', fontFamily:'monospace', fontSize:12, padding:'10px 12px', outline:'none', borderRadius:8, width:'100%' };
const tabOn:CSSProperties={ background:'#1d3a6e', border:'1px solid #2563eb55', color:'#93c5fd', padding:'8px 12px', borderRadius:8, fontFamily:'monospace', fontSize:11, cursor:'pointer' };
const tabOff:CSSProperties={ background:'transparent', border:'1px solid #1c2d45', color:'#64748b', padding:'8px 12px', borderRadius:8, fontFamily:'monospace', fontSize:11, cursor:'pointer' };
