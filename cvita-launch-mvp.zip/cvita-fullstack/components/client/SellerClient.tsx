"use client";

import { useMemo, useState, type CSSProperties } from "react";
import { Btn, Card, SectionLabel, Badge } from "@/components/ui";
import { T } from "@/components/theme";

type Product = {
  id: string;
  title: string;
  description: string;
  type: "COURSE" | "TEMPLATE" | "EBOOK" | "WORKSHOP" | "LECTURE";
  priceCents: number;
  published: boolean;
  students: number;
  reviews: number;
  tags: { id: string; label: string }[];
};

const emptyForm = { id: "", title: "", description: "", type: "COURSE" as Product["type"], price: "49", tags: "", published: true };

export function SellerClient({ initialProducts }: { initialProducts: Product[] }) {
  const [products, setProducts] = useState(initialProducts);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const totalRevenuePreview = useMemo(() => products.reduce((sum, item) => sum + item.students * item.priceCents, 0), [products]);

  async function submit() {
    setSaving(true);
    setMessage(null);
    const payload = {
      id: form.id || undefined,
      title: form.title,
      description: form.description,
      type: form.type,
      priceCents: Math.round(Number(form.price) * 100),
      tags: form.tags.split(",").map((tag) => tag.trim()).filter(Boolean),
      published: form.published
    };
    const method = form.id ? "PATCH" : "POST";
    const response = await fetch("/api/seller/products", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    setSaving(false);
    if (!response.ok) {
      setMessage(data.error || data.detail || "Could not save product");
      return;
    }

    setProducts((current) => {
      if (form.id) return current.map((item) => item.id === data.id ? data : item);
      return [data, ...current];
    });
    setForm(emptyForm);
    setMessage(form.id ? "Product updated." : "Product published.");
  }

  function startEdit(product: Product) {
    setForm({
      id: product.id,
      title: product.title,
      description: product.description,
      type: product.type,
      price: String(product.priceCents / 100),
      tags: product.tags.map((tag) => `#${tag.label}`).join(", "),
      published: product.published
    });
  }

  return (
    <main style={{ maxWidth: 1120, margin: "0 auto", padding: 24 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1.8fr", gap: 16 }}>
        <Card style={{ height: "fit-content" }}>
          <SectionLabel>SELLER STUDIO</SectionLabel>
          <h1 style={{ margin: "0 0 12px", fontSize: 30 }}>{form.id ? "Edit knowledge product" : "Publish a knowledge product"}</h1>
          <div style={{ display: "grid", gap: 10 }}>
            <input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} style={inputStyle} placeholder="Title" />
            <textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} style={{ ...inputStyle, minHeight: 120 }} placeholder="Explain what the buyer gets, outcomes, and format." />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 140px", gap: 10 }}>
              <select value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as Product["type"] }))} style={inputStyle}>
                <option value="COURSE">Course</option>
                <option value="TEMPLATE">Template</option>
                <option value="EBOOK">eBook</option>
                <option value="WORKSHOP">Workshop</option>
                <option value="LECTURE">Lecture</option>
              </select>
              <input value={form.price} onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))} style={inputStyle} placeholder="49" />
            </div>
            <input value={form.tags} onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))} style={inputStyle} placeholder="#DesignSystems, #Figma" />
            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 14, color: T.mid }}>
              <input type="checkbox" checked={form.published} onChange={(e) => setForm((f) => ({ ...f, published: e.target.checked }))} />
              Published and visible in marketplace
            </label>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <Btn onClick={submit} disabled={saving}>{saving ? "Saving…" : form.id ? "Update product" : "Publish product"}</Btn>
              {form.id && <Btn onClick={() => setForm(emptyForm)} style={{ background: "transparent", color: T.mid, border: `1px solid ${T.border}` }}>Cancel edit</Btn>}
              {message && <span style={{ fontFamily: "monospace", fontSize: 11, color: T.blue }}>{message}</span>}
            </div>
          </div>
        </Card>

        <div>
          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>SELLER SNAPSHOT</SectionLabel>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
              <Metric label="Products" value={String(products.length)} />
              <Metric label="Student count" value={String(products.reduce((sum, item) => sum + item.students, 0))} />
              <Metric label="Gross preview" value={`$${(totalRevenuePreview / 100).toLocaleString()}`} />
            </div>
          </Card>

          <Card>
            <SectionLabel>YOUR CATALOG</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {products.length === 0 ? <div style={{ color: T.mute }}>No products yet.</div> : products.map((product) => (
                <div key={product.id} style={{ border: `1px solid ${T.border}`, borderRadius: 12, padding: 14, background: T.bg }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, marginBottom: 8 }}>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 18 }}>{product.title}</div>
                      <div style={{ color: T.mid, fontSize: 13 }}>{product.type} · ${(product.priceCents / 100).toFixed(2)}</div>
                    </div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <Badge label={product.published ? "Published" : "Draft"} color={product.published ? T.green : T.gold} bg={product.published ? T.greenBg : T.goldBg} />
                      <Btn onClick={() => startEdit(product)}>Edit</Btn>
                    </div>
                  </div>
                  <div style={{ color: T.mid, lineHeight: 1.6, marginBottom: 8 }}>{product.description}</div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
                    {product.tags.map((tag) => <Badge key={tag.id} label={`#${tag.label}`} color={T.blue} bg={T.blueBg} />)}
                  </div>
                  <div style={{ fontFamily: "monospace", fontSize: 12, color: T.mute }}>{product.students} learners · {product.reviews} reviews</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div style={{ padding: 14, borderRadius: 12, background: T.bg, border: `1px solid ${T.border}` }}><div style={{ fontFamily: "monospace", fontSize: 10, color: T.mute, marginBottom: 6 }}>{label}</div><div style={{ fontSize: 24, fontWeight: 900 }}>{value}</div></div>;
}

const inputStyle: CSSProperties = { background: T.surface, border: `1px solid ${T.border}`, borderRadius: 10, padding: "11px 12px", fontSize: 14, outline: "none", width: "100%" };
