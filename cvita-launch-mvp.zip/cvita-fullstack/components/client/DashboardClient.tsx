"use client";

import { useMemo, useState, type CSSProperties, type ReactNode } from "react";
import { Badge, Btn, Card, SectionLabel } from "@/components/ui";
import { T } from "@/components/theme";

type ProfilePayload = {
  id: string;
  slug: string;
  title: string;
  location: string;
  status: string;
  summary: string | null;
  careerScore: number;
  user: { fullName: string; plan: string; aiCredits: number };
  hashtags: { id: string; label: string }[];
  experiences: { id: string; title: string; organization: string; period: string; bullets: string[] }[];
  patents: { id: string; title: string; number: string; status: string }[];
  ventures: { id: string; name: string; role: string; stage: string; revenue: string; teamSize: number }[];
};

export function DashboardClient({ initialProfile }: { initialProfile: ProfilePayload }) {
  const [profile, setProfile] = useState(initialProfile);
  const [form, setForm] = useState({
    slug: initialProfile.slug,
    title: initialProfile.title,
    location: initialProfile.location,
    status: initialProfile.status,
    summary: initialProfile.summary ?? "",
    hashtagsText: initialProfile.hashtags.map((tag) => `#${tag.label}`).join(", "),
    experiences: initialProfile.experiences.map((item) => ({ ...item, bulletsText: item.bullets.join("\n") })),
    patents: initialProfile.patents.map((item) => ({ ...item })),
    ventures: initialProfile.ventures.map((item) => ({ ...item, teamSizeText: String(item.teamSize) }))
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const parsedCareerStrength = useMemo(() => {
    const signals = [
      form.summary.trim().length > 40,
      form.hashtagsText.trim().length > 0,
      form.experiences.length > 0,
      form.patents.length > 0 || form.ventures.length > 0,
      form.slug.trim().length >= 3
    ].filter(Boolean).length;
    return Math.min(100, 60 + signals * 8);
  }, [form]);

  function setField<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function saveProfile() {
    setSaving(true);
    setError(null);
    setMessage(null);

    const payload = {
      slug: form.slug,
      title: form.title,
      location: form.location,
      status: form.status,
      summary: form.summary,
      hashtags: form.hashtagsText.split(",").map((tag) => tag.trim()).filter(Boolean),
      experiences: form.experiences.map((item) => ({
        title: item.title.trim(),
        organization: item.organization.trim(),
        period: item.period.trim(),
        bullets: item.bulletsText.split("\n").map((line) => line.trim()).filter(Boolean)
      })).filter((item) => item.title && item.organization && item.period && item.bullets.length),
      patents: form.patents.map((item) => ({ title: item.title.trim(), number: item.number.trim(), status: item.status.trim() })).filter((item) => item.title && item.number && item.status),
      ventures: form.ventures.map((item) => ({
        name: item.name.trim(),
        role: item.role.trim(),
        stage: item.stage.trim(),
        revenue: item.revenue.trim(),
        teamSize: Number(item.teamSizeText)
      })).filter((item) => item.name && item.role && item.stage && item.revenue && Number.isFinite(item.teamSize) && item.teamSize > 0)
    };

    const response = await fetch("/api/profile/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    setSaving(false);

    if (!response.ok) {
      setError(data.detail || data.error || "Could not save profile");
      return;
    }

    setProfile(data);
    setForm({
      slug: data.slug,
      title: data.title,
      location: data.location,
      status: data.status,
      summary: data.summary ?? "",
      hashtagsText: data.hashtags.map((tag: { label: string }) => `#${tag.label}`).join(", "),
      experiences: data.experiences.map((item: { id: string; title: string; organization: string; period: string; bullets: string[] }) => ({ ...item, bulletsText: item.bullets.join("\n") })),
      patents: data.patents.map((item: { id: string; title: string; number: string; status: string }) => ({ ...item })),
      ventures: data.ventures.map((item: { id: string; name: string; role: string; stage: string; revenue: string; teamSize: number }) => ({ ...item, teamSizeText: String(item.teamSize) }))
    });
    setMessage("Profile saved to the database.");
  }

  return (
    <main style={{ maxWidth: 1180, margin: "0 auto", padding: 24 }}>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        <div>
          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>PROFILE EDITOR</SectionLabel>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start", marginBottom: 14 }}>
              <div>
                <h1 style={{ margin: "0 0 6px", fontSize: 32 }}>{profile.user.fullName}</h1>
                <div style={{ color: T.mid }}>Editing your live dashboard profile</div>
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                <Badge label={profile.user.plan} color={T.blue} bg={T.blueBg} />
                <Badge label={`${profile.user.aiCredits} AI credits`} color={T.purple} bg={T.purpleBg} />
                <Badge label={form.status || "No status"} color={T.green} bg={T.greenBg} />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <Input label="Title" value={form.title} onChange={(value) => setField("title", value)} />
              <Input label="Location" value={form.location} onChange={(value) => setField("location", value)} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <Input label="Public slug" value={form.slug} onChange={(value) => setField("slug", value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <Input label="Status" value={form.status} onChange={(value) => setField("status", value)} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <TextArea label="Summary" rows={5} value={form.summary} onChange={(value) => setField("summary", value)} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <TextArea label="Hashtags" rows={3} value={form.hashtagsText} onChange={(value) => setField("hashtagsText", value)} hint="Comma-separated. Example: #ProductDesign, #Figma, #AI" />
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <Btn onClick={saveProfile} disabled={saving}>{saving ? "Saving..." : "Save profile"}</Btn>
              <Btn href={`/u/${form.slug}`} style={{ background: "transparent", color: T.mid, border: `1px solid ${T.border}` }}>Open public profile</Btn>
              {message && <span style={{ fontFamily: "monospace", fontSize: 11, color: T.green }}>{message}</span>}
              {error && <span style={{ fontFamily: "monospace", fontSize: 11, color: T.red }}>{error}</span>}
            </div>
          </Card>

          <EditableListCard
            title="EXPERIENCE"
            items={form.experiences}
            onAdd={() => setField("experiences", [...form.experiences, { id: crypto.randomUUID(), title: "", organization: "", period: "", bulletsText: "" }])}
            onChange={(items) => setField("experiences", items)}
            renderItem={(item, index, update, remove) => (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 160px auto", gap: 8, marginBottom: 8 }}>
                  <input value={item.title} onChange={(e) => update(index, { ...item, title: e.target.value })} style={inputStyle} placeholder="Role" />
                  <input value={item.organization} onChange={(e) => update(index, { ...item, organization: e.target.value })} style={inputStyle} placeholder="Company" />
                  <input value={item.period} onChange={(e) => update(index, { ...item, period: e.target.value })} style={inputStyle} placeholder="2022–Present" />
                  <button onClick={() => remove(index)} style={smallGhostButton}>Remove</button>
                </div>
                <textarea value={item.bulletsText} onChange={(e) => update(index, { ...item, bulletsText: e.target.value })} style={{ ...inputStyle, minHeight: 96, width: "100%" }} placeholder={"One bullet per line\nLed redesign of component library\nMentored 4 designers"} />
              </div>
            )}
          />

          <EditableListCard
            title="PATENTS"
            items={form.patents}
            onAdd={() => setField("patents", [...form.patents, { id: crypto.randomUUID(), title: "", number: "", status: "" }])}
            onChange={(items) => setField("patents", items)}
            renderItem={(item, index, update, remove) => (
              <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr 140px auto", gap: 8 }}>
                <input value={item.title} onChange={(e) => update(index, { ...item, title: e.target.value })} style={inputStyle} placeholder="Patent title" />
                <input value={item.number} onChange={(e) => update(index, { ...item, number: e.target.value })} style={inputStyle} placeholder="US11..." />
                <input value={item.status} onChange={(e) => update(index, { ...item, status: e.target.value })} style={inputStyle} placeholder="Granted" />
                <button onClick={() => remove(index)} style={smallGhostButton}>Remove</button>
              </div>
            )}
          />
        </div>

        <div>
          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>LIVE PREVIEW</SectionLabel>
            <div style={{ fontSize: 46, fontWeight: 900, color: T.gold }}>{profile.careerScore}</div>
            <div style={{ color: T.mute, fontFamily: "monospace", fontSize: 11, marginBottom: 8 }}>Stored career score</div>
            <div style={{ height: 8, background: T.border, borderRadius: 999, marginBottom: 12 }}>
              <div style={{ width: `${profile.careerScore}%`, height: "100%", borderRadius: 999, background: `linear-gradient(90deg,${T.gold},#f59e0b)` }} />
            </div>
            <div style={{ fontSize: 22, fontWeight: 800, color: T.blue }}>{parsedCareerStrength}</div>
            <div style={{ color: T.mid, fontSize: 13 }}>Editor completeness signal based on what you filled in right now.</div>
          </Card>

          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>PUBLIC URL</SectionLabel>
            <div style={{ fontFamily: "monospace", fontSize: 12, color: T.blue }}>/u/{form.slug}</div>
            <div style={{ color: T.mid, fontSize: 13, marginTop: 6 }}>Use this as the shareable public profile URL once deployed.</div>
          </Card>

          <Card style={{ marginBottom: 14 }}>
            <SectionLabel>LIVE HASHTAGS</SectionLabel>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {form.hashtagsText.split(",").map((tag) => tag.trim()).filter(Boolean).map((tag) => (
                <Badge key={tag} label={tag.startsWith("#") ? tag : `#${tag}`} color={T.gold} bg={T.goldBg} />
              ))}
            </div>
          </Card>

          <EditableListCard
            title="VENTURES"
            items={form.ventures}
            onAdd={() => setField("ventures", [...form.ventures, { id: crypto.randomUUID(), name: "", role: "", stage: "", revenue: "", teamSizeText: "1" }])}
            onChange={(items) => setField("ventures", items)}
            renderItem={(item, index, update, remove) => (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 8, marginBottom: 8 }}>
                  <input value={item.name} onChange={(e) => update(index, { ...item, name: e.target.value })} style={inputStyle} placeholder="Venture name" />
                  <input value={item.role} onChange={(e) => update(index, { ...item, role: e.target.value })} style={inputStyle} placeholder="Founder & CEO" />
                  <button onClick={() => remove(index)} style={smallGhostButton}>Remove</button>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 110px", gap: 8 }}>
                  <input value={item.stage} onChange={(e) => update(index, { ...item, stage: e.target.value })} style={inputStyle} placeholder="Seed" />
                  <input value={item.revenue} onChange={(e) => update(index, { ...item, revenue: e.target.value })} style={inputStyle} placeholder="$18k MRR" />
                  <input value={item.teamSizeText} onChange={(e) => update(index, { ...item, teamSizeText: e.target.value })} style={inputStyle} placeholder="3" />
                </div>
              </div>
            )}
          />
        </div>
      </div>
    </main>
  );
}

function EditableListCard<T>({
  title,
  items,
  onAdd,
  onChange,
  renderItem
}: {
  title: string;
  items: T[];
  onAdd: () => void;
  onChange: (items: T[]) => void;
  renderItem: (item: T, index: number, update: (index: number, next: T) => void, remove: (index: number) => void) => ReactNode;
}) {
  function update(index: number, next: T) {
    onChange(items.map((item, currentIndex) => currentIndex === index ? next : item));
  }

  function remove(index: number) {
    onChange(items.filter((_, currentIndex) => currentIndex !== index));
  }

  return (
    <Card style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", marginBottom: 12 }}>
        <SectionLabel>{title}</SectionLabel>
        <button onClick={onAdd} style={smallGhostButton}>+ Add</button>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 ? <div style={{ color: T.mute, fontSize: 13 }}>Nothing here yet.</div> : items.map((item, index) => <div key={index} style={{ padding: 12, borderRadius: 10, border: `1px solid ${T.border}`, background: T.bg }}>{renderItem(item, index, update, remove)}</div>)}
      </div>
    </Card>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 13, color: T.mid }}><span>{label}</span><input value={value} onChange={(event) => onChange(event.target.value)} style={inputStyle} /></label>;
}

function TextArea({ label, value, onChange, rows, hint }: { label: string; value: string; onChange: (value: string) => void; rows: number; hint?: string }) {
  return <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 13, color: T.mid }}><span>{label}</span><textarea rows={rows} value={value} onChange={(event) => onChange(event.target.value)} style={{ ...inputStyle, minHeight: rows * 22 }} />{hint ? <span style={{ fontSize: 11, color: T.mute }}>{hint}</span> : null}</label>;
}

const inputStyle: CSSProperties = { background: T.surface, border: `1px solid ${T.border}`, borderRadius: 10, padding: "10px 12px", outline: "none", fontSize: 14 };
const smallGhostButton: CSSProperties = { background: "transparent", border: `1px solid ${T.border}`, borderRadius: 8, color: T.mid, fontFamily: "monospace", fontSize: 11, padding: "8px 10px", cursor: "pointer" };
