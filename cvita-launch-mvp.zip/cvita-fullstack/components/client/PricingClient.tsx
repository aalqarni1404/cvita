"use client";

import { useState } from "react";
import { Btn } from "@/components/ui";
import { T } from "@/components/theme";

export function PricingClient({ isAuthed }: { isAuthed: boolean }) {
  const [loading, setLoading] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function startCheckout(plan: "PRO" | "CREATOR" | "ENTERPRISE") {
    if (!isAuthed) {
      setMessage("Sign in first. Billing checkout is protected now.");
      return;
    }
    setLoading(plan);
    setMessage(null);
    try {
      const response = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan, interval: "MONTH" })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Checkout failed");
      if (data.url) {
        window.location.href = data.url;
        return;
      }
      setMessage(data.message || "Stripe is not configured yet.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Checkout failed");
    } finally {
      setLoading(null);
    }
  }

  async function openPortal() {
    setLoading("portal");
    setMessage(null);
    try {
      const response = await fetch("/api/billing/portal", { method: "POST" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Portal failed");
      if (data.url) {
        window.location.href = data.url;
        return;
      }
      setMessage(data.message || "Portal unavailable.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Portal failed");
    } finally {
      setLoading(null);
    }
  }

  return (
    <div style={{ marginTop: 18, textAlign: "center" }}>
      {message && <div style={{ fontFamily: "monospace", fontSize: 11, color: T.blue, marginBottom: 12 }}>{message}</div>}
      <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
        <Btn onClick={() => startCheckout("PRO")} disabled={loading !== null}>{loading === "PRO" ? "Opening…" : "Start Pro"}</Btn>
        <Btn onClick={() => startCheckout("CREATOR")} disabled={loading !== null} style={{ background: `linear-gradient(135deg,${T.gold},#f59e0b)` }}>{loading === "CREATOR" ? "Opening…" : "Start Creator"}</Btn>
        <Btn onClick={() => startCheckout("ENTERPRISE")} disabled={loading !== null} style={{ background: "linear-gradient(135deg,#1e2d45,#243450)" }}>{loading === "ENTERPRISE" ? "Opening…" : "Start Enterprise"}</Btn>
        <Btn onClick={openPortal} disabled={loading !== null} style={{ background: "transparent", color: T.mid, border: `1px solid ${T.border}` }}>{loading === "portal" ? "Opening…" : "Billing Portal"}</Btn>
      </div>
    </div>
  );
}
